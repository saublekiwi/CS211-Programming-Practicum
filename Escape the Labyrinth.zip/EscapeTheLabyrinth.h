#include <utility>
#include <random>
#include <set>
#include "grid.h"
#include "maze.h"
using namespace std;

/* Change constant kYourNetID to store your netID 
 *    - your submission will be manually inspected to ensure
 *      you have used the exact string that is your netID
 *    - thus, it is vital you understand what your netID is
 *    - ex: Professor Reckinger's email is scotreck@uic.edu, so
 *          Professor Reckinger's netID is scotreck     
 *    - ex: Professor Kidane's email is ekidan2@uic.edu, so
 *          Professor Kidane's netID is ekidan2     
 *    - ex: Student Sparky's email is sspark211@uic.edu, so
 *          Student Sparky's netID is sspark211 
 * WARNING: Once you've set set this constant and started 
 * exploring your maze, do NOT edit the value of kYourNetID. 
 * Changing kYourNetID will change which maze you get back, 
 * which might invalidate all your hard work!
 */
const string kYourNetID = "mlaug4";

/* Change these constants to contain the paths out of your mazes. */
const string kPathOutOfRegularMaze = "SSSENSWNNNEESEWSES";
const string kPathOutOfTwistyMaze = "ESWWENNW";

void checkHere(bool* spellFound, bool* potFound, bool* wandFound, string* whatsHere) { // checks a cell passed by reference to see if it has any key items, updates the appropriate tracking bool
    if (*whatsHere == "Spellbook") {
        *spellFound = true;
    }
    else if (*whatsHere == "Potion") {
        *potFound = true;
    }
    else if (*whatsHere == "Wand") {
        *wandFound = true;
    }
}

bool isPathToFreedom(MazeCell *start, const string& moves) {

    // tracks if the key items have been found
    bool spellFound = false;
    bool potFound = false;
    bool wandFound = false;

    MazeCell* currCell = start;

    for (char c : moves) { // loops through each character (move) in the moves string
        checkHere(&spellFound, &potFound, &wandFound, &(currCell->whatsHere)); // checks for key item
        
        // tries to make the move
        if (c == 'N' && currCell->north != nullptr) {
            currCell = currCell->north;
        }
        else if (c == 'S' && currCell->south != nullptr) {
            currCell = currCell->south;
        }
        else if (c == 'E' && currCell->east != nullptr) {
            currCell = currCell->east;
        }
        else if (c == 'W' && currCell->west != nullptr) {
            currCell = currCell->west;
        }

        else { // if the character isn't N/S/E/W or the pointer is null
            return false;
        }
    }

    checkHere(&spellFound, &potFound, &wandFound, &(currCell->whatsHere)); // checks the final cell moved to for a key item

    if (!spellFound || !potFound || !wandFound) { // if any of them are not found
        return false;
    }

    return true;
}
