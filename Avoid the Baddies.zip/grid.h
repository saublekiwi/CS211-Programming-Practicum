//-------------------------------------------------
// Martin Laugesen
// CS 211, Fall 2023
// This file contains the Grid class, with constructors, copiers, a destructor,
// and some other useful functions. The Grid class is a row array of collumn arrays,
// which can contain any datatype. The Grid is 4x4 by defualt or can be assigned.
//-------------------------------------------------


#pragma once

#include <iostream>
#include <exception>
#include <stdexcept>
#include <algorithm>

using namespace std;

template<typename T>
class Grid {
private:
  struct ROW {
    T*  Cols;     // array of column elements
    size_t NumCols;  // total number of columns
  };

  ROW* Rows;     // array of ROWs
  size_t  NumRows;  // total number of rows
    
public:
  //
  // default constructor:
  //
  // Called automatically by to construct a 4x4 Grid. 
  // All elements initialized to default value of T.
  //
  Grid() {
    Rows = new ROW[4];  // 4 rows
    NumRows = 4;

    // initialize each row to have 4 columns:
    for (size_t r = 0; r < NumRows; ++r) {
      Rows[r].Cols = new T[4];
      Rows[r].NumCols = 4;

      // initialize the elements to their default value:
      for (size_t c = 0; c < Rows[r].NumCols; ++c) {
        Rows[r].Cols[c] = T();  // default value for type T:
      }
    }
  }

  //
  // parameterized constructor:
  //
  // Called automatically to construct a Grid 
  // with R rows, where each row has C columns. 
  // All elements initialized to default value of T.
  //
  Grid(size_t R, size_t C) {
    if (R < 1) {
        throw invalid_argument("LetterGrid::constructor: # of rows");
    }
    if (C < 1) {
        throw invalid_argument("LetterGrid::constructor: # of cols");
    }
        
    Rows = new ROW[R]; // Allocate memory for the array
    NumRows = R;

    for (size_t r = 0; r < NumRows; ++r) { // Loop through each row in the grid
        Rows[r].Cols = new T[C]; // Allocate memory for the array
        Rows[r].NumCols = C;
        for (size_t c = 0; c < Rows[r].NumCols; ++c) { // initialize each column element with default value
            Rows[r].Cols[c] = T(); // default value for type T:
        }
    }
  }
    
  //
  // destructor:
  //
  // Called automatically to free memory for this Grid.
  //
  virtual ~Grid() {
    for (size_t r = 0; r < NumRows; ++r) { // loop through each row of the grid
        delete[] Rows[r].Cols; // delete the array of columns in the current row
    }

    delete[] Rows; // delete the array of rows itself
  }


  //
  // copy constructor:
  //
  // Called automatically to construct a Grid that contains a
  // copy of an existing Grid.  Example: this occurs when passing
  // Grid as a parameter by value
  //
  //   void somefunction(Grid<int> G2)  <--- G2 is a copy:
  //   { ... }
  //
  Grid(const Grid<T>& other) {
    Rows = new ROW[other.NumRows]; // Allocate memory for the rows of the grid based on the number of rows in the other object
    NumRows = other.NumRows; // copy the number of rows from other into NumRows object

    for (size_t r = 0; r < other.NumRows; ++r) {
        size_t other_numcols = other.Rows[r].NumCols; // gets the number of columns in the current row of other object

        Rows[r].Cols = new T[other_numcols]; // allocate memory for the columns in the current row
        Rows[r].NumCols = other_numcols; // copy the number of columns from the current row

        for (size_t c = 0; c < other_numcols; ++c) {
            Rows[r].Cols[c] = other.Rows[r].Cols[c]; // copy each element from the other object's grid
        }
    }
  }
    
  //
  // copy operator=
  //
  // Called when one Grid is assigned into another, i.e. this = other;
  //
  Grid& operator=(const Grid& other) {
    if (this == &other) {
        return *this; // if the same object, return the current
    }
    
    for (size_t r = 0; r < NumRows; ++r) {
        delete[] Rows[r].Cols; // deletes the columns in each row
    }
    delete[] Rows; // Delete array of Rows after columns are deleted
        
    this->Rows = new ROW[other.NumRows]; // allocate memory for Rows based on the size of the other object
    this->NumRows = other.NumRows; // set number of rows to match other
        
    for (size_t r = 0; r < other.NumRows; ++r) {
        size_t other_numcols = other.Rows[r].NumCols; // Number of columns in the current row
        
        this->Rows[r].Cols = new T[other_numcols]; // allocate memory for columns and set the number of columns
        this->Rows[r].NumCols = other_numcols; // allocate memory for columns and set the number of columns
        
        for (size_t c = 0; c < other_numcols; ++c) { 
            this->Rows[r].Cols[c] = other.Rows[r].Cols[c]; // copy the elements from other to the Rows object by row
        }
    }

    return *this;
  }

  //
  // numrows
  //
  // Returns the # of rows in the Grid.  
  // The indices for these rows are 0..numrows-1.
  //
  size_t numrows() const {
    return NumRows;
  }
  

  //
  // numcols
  //
  // Returns the # of columns in row r.  
  // The indices for these columns are 0..numcols-1.  
  // For now, each row has the same number of columns.
  //
  size_t numcols(size_t r) const {
    return Rows[r].NumCols;
  }


  //
  // size
  //
  // Returns the total # of elements in the Grid.
  //
  size_t size() const {
    return NumRows * Rows[0].NumCols;
  }


  //
  // ()
  //
  // Returns a reference to the element at location (r, c);
  // this allows you to access or assign the element:
  //
  //    grid(r, c) = ...
  //    cout << grid(r, c) << endl;
  //
  T& operator()(size_t r, size_t c) {
    if (r < 0 || r >= NumRows) {
        throw invalid_argument("LetterGrid::constructor: # of rows");
    }
    else if (c < 0 || c >= Rows[r].NumCols) {
        throw invalid_argument("LetterGrid::constructor: # of cols");
    }

    return Rows[r].Cols[c];
  }

  //
  // _output
  //
  // Outputs the contents of the grid; for debugging purposes.  
  // This is not tested.
  //
  void _output() {
    for (size_t r = 0; r < NumRows; ++r) { // loop over each row in reverse order to print from top row to the bottom
            cout << "| "; // start new row with this
            for (size_t c = 0; c < Rows[r].NumCols; ++c) {
                cout << Rows[NumRows-r-1].Cols[c] << " | "; // print the letter at the current column in the reversed row
            }
            cout << endl;
        }
  }

};
