#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

typedef struct Pattern_struct {
    char* pat;  //string pattern - exs: "hello", "-ell-", "-----"
    int count;  //frequency of pattern in the current word list
    int changes;//number of occurences of new letter in this pattern
} Pattern;


//-------------------------------------------------------------------
// TODO - Task II: write addWord() function, which adds a new word to
//      a dynamic heap-allocated array of C-strings; heap-space must  
//      be allocated for the new word inside this function, then copy  
//      the chars from newWord to the newly allocated heap-space; if
//      adding the new word pushes numWords above maxWords, then 
//      realloate the words array with double the capacity
//      parameters: 
//          char*** words - array of C-strings passed-by-pointer
//              note: *words is an array of pointers
//                    **words is an array of chars
//                    ***words is a char  
//                    (*words)[0] is the 1st C-string in the array
//                    (*words)[1] is the 2nd C-string in the array
//                    (*words)[0][0] is 1st char of 1st C-string
//                    (*words)[1][2] is 3rd char of 2nd C-string
//                    etc.
//          int* numWords - current # of words in *words array
//               note: numWords will increase by 1 here, 
//                     so it is passed-by-pointer
//          int* maxWords - current capacity of *words array
//               note: maxWords may increase by x2 here, 
//                     so it is passed-by-pointer
//          char* newWord - C-string word to be added to words
//               note: newWord is a C-string, automatically a pointer
//-------------------------------------------------------------------
void addWord(char*** words, int* numWords, int* maxWords, char* newWord) {
    if ((*numWords) >= (*maxWords)) { // checks if more space is needed for the word array and doubles the size if necessary
        char** updatedWords = (char**)malloc(sizeof(char*) * (*maxWords * 2));

        for (int i = 0; i < *numWords; i++) { // adds words to new array
            updatedWords[i] = (*words)[i];
        }

        free(*words); 
        (*words) = updatedWords;

        (*maxWords) *= 2;
    }

    // Adds the new word to the array and updates the numWords counter
    (*words)[*numWords] = (char*)malloc(sizeof(char) * (strlen(newWord) + 1));

    strcpy((*words)[*numWords], newWord);

    (*numWords)++;
}

//-------------------------------------------------------------------
// TODO - Task V: write the strNumMods() function, which
//      returns count of character differences between two strings;
//      includes extra characters in longer string if different lengths
// Exs: str1 = magic, str2 = magic, returns 0
//      str1 = wands, str2 = wants, returns 1
//      str1 = magic, str2 = wands, returns 4
//      str1 = magic, str2 = mag, returns 2
//      str1 = magic, str2 = magicwand, returns 4
//      str1 = magic, str2 = darkmagic, returns 8
//-------------------------------------------------------------------
int strNumMods(char* str1, char* str2) {
    int difference = 0;

    if (strlen(str2) > strlen(str1)) { // checks if the second string is longer, and swaps it with the first if so
        char* temp;

        temp = str2;
        str2 = str1;
        str1 = temp;
    }

    difference += (strlen(str1) - strlen(str2)); // accounts for string length

    while (*str2 != '\0') { //loops through the strings, checking if they are the same, and tracking the numbmer of times they aren't
        if (*str1 != *str2) {
            difference++;
        }
        str1++;
        str2++;
    }

    return difference;
}

//-------------------------------------------------------------------
// TODO - Task VI: write the strDiffInd() function, which
//      returns index of the character where two strings first differ, &
//      returns strlen(str1) = strlen(str2) if no differences
// Exs: str1 = magic, str2 = magic, returns 5
//      str1 = wands, str2 = wants, returns 3
//      str1 = magic, str2 = wands, returns 0
//      str1 = magic, str2 = mag, returns 3
//      str1 = magic, str2 = magicwand, returns 5
//      str1 = magic, str2 = darkmagic, returns 0
//-------------------------------------------------------------------
int strDiffInd(char* str1, char* str2) {
    int indexDiff = 0;
    
    if (strlen(str2) > strlen(str1)) { // checks if the second string is longer, and swaps it with the first if so
        char* temp;

        temp = str2;
        str2 = str1;
        str1 = temp;
    }

    while (*str2 != '\0') { // loops through the strings, returning the index of the first difference
        if (*str1 != *str2) {
            return indexDiff;
        }

        str1++;
        str2++;
        indexDiff++;
    }

    return indexDiff;
}

int main(int argc, char* argv[]) {

    printf("Welcome to the (Evil) Word Guessing Game!\n\n");
    
    bool solved = false;
    
    //-------------------------------------------------------------------
    // TODO - Task I: handle command-line arguments
    // command-line arguments:
    //  [-n wordSize] = sets number of characters in word to be guessed;
    //                  if dictionary has no words of length wordSize,
    //                  then print:
    //                    "Dictionary has no words of length [wordSize]."
    //                    "Terminating program..."
    //                  default wordSize = 5
    // [-g numGuesses] = sets number of unsuccessful letter guesses;
    //                   numGuesses must be a positive integer,
    //                   otherwise print 
    //                     "Invalid number of guesses."
    //                     "Terminating program..."
    //                   default numGuesses = 26 
    //                   (note: 26 guesses guarantees player can win)
    // [-s] = stats mode, which includes printing of dictionary 
    //                    statistics AND number of possible words 
    //                    remaining during gameplay.
    //                    default is OFF
    // [-w] = word list mode, which includes a print out of the full 
    //                        list of possible words before every guess.
    //                        default is OFF
    // [-l] = letter list mode, which prints out a list of previously 
    //                          guessed letters before each new guess
    //                          default is OFF
    // [-p] = pattern list mode, which prints out a list of all patterns 
    //                           in the word list, together with the
    //                           frequency of each pattern and the 
    //                           number of changes in the pattern due to
    //                           the current guess
    //                           default is OFF
    // [-v] = verbose mode, which turns ON stats mode, word list mode, 
    //                      letter list mode, AND pattern list mode
    // [-x] = extension mode, which is an optional extra credit 
    //                        extension doing something interesting with
    //                        the evil word game, e.g. optimizing the 
    //                        algorithm to predict future guesses
    //-------------------------------------------------------------------
    
    int wordSize = 5;
    int numGuesses = 26;
    bool statsMode = 0, wordListMode = 0, letterListMode = 0, patternListMode = 0;

    for (int i = 1; i < argc; i++) { // loops through the command line arguments
        if (!strcmp(argv[i], "-n")) { // finds wordsize if input
            wordSize = atoi(argv[i + 1]);
            i++;

            if (wordSize < 2) {
                printf("Invalid word size.\nTerminating program...\n");
                return 0;
            }
        }
        
        else if (!strcmp(argv[i], "-g")) { // finds number of guesses if input
            numGuesses = atoi(argv[i + 1]);
            i++;

            if (numGuesses < 1) {
                printf("Invalid number of guesses.\nTerminating program...");
                return 0;
            }
        }

        else if (!strcmp(argv[i], "-s")) {
            statsMode = 1;
        }

        else if (!strcmp(argv[i], "-w")) {
            wordListMode = 1;
        }

        else if (!strcmp(argv[i], "-l")) {
            letterListMode = 1;
        }

        else if (!strcmp(argv[i], "-p")) {
            patternListMode = 1;
        }

        else if (!strcmp(argv[i], "-v")) {
            statsMode = 1;
            wordListMode = 1;
            letterListMode = 1;
            patternListMode = 1;
        }

        else {
            printf("Invalid command-line argument.\nTerminating program...");
            return 0;
        }
    }

    printf("Game Settings:\n  Word Size = %d\n  Number of Guesses = %d\n  View Stats Mode = ", wordSize, numGuesses);
    if (statsMode) {
        printf("ON\n");
    }
    else {
        printf("OFF\n");
    }

    printf("  View Word List Mode = ");
    if (wordListMode) {
        printf("ON\n");
    }
    else {
        printf("OFF\n");
    }

    printf("  View Letter List Mode = ");
    if (letterListMode) {
        printf("ON\n");
    }
    else {
        printf("OFF\n");
    }

    printf("  View Pattern List Mode = ");
    if (patternListMode) {
        printf("ON\n");
    }
    else {
        printf("OFF\n");
    }
    
    //-------------------------------------------------------------------
    // TODO - Task III: file-read the word list from dictionary.txt, 
    //                  storing only words of length set by wordSize 
    //                  (a command-line argument) in a dynamically
    //                  growing heap-allocated array of C-strings:
    //                      - the word list should be a dynamic array of 
    //                        pointers, initially with maximum size 4, 
    //                        doubling in maximum size whenever more 
    //                        space is needed
    //                      - each element of the word list array should 
    //                        point to a heap-allocated C-string that 
    //                        can store a word containing exactly 
    //                        wordSize lower-case letters
    //-------------------------------------------------------------------

    int capacity = 4;

    char** wordList = (char**)malloc(capacity*sizeof(char*));

    int numWords = 0, numWordsAdded = 0, maxWordLen = 0;
    char longestWord[50] = "";

    FILE *dict = fopen("dictionary.txt", "r");
    char word[50];

    while (!feof(dict)) { // loops through the dictionary
        fscanf(dict, " %s", word);

        if (strlen(word) > maxWordLen) { // checks if the current word is longer than the record, and updates it if so
            maxWordLen = strlen(word);
            strcpy(longestWord, word);
        }

        if (strlen(word) == wordSize) { // adds word to the wordlist if correct size
            addWord(&wordList, &numWordsAdded, &capacity, word);
        }

        numWords++;
    }

    fclose(dict);

    //-------------------------------------------------------------------
    // TODO - Task IV: display dictionary stats [-s] & word list [-w] 
    //                 if the proper command-line flags are turned ON;
    //                 see sample output for proper formatting 
    //-------------------------------------------------------------------
    
    if (statsMode) {
        printf("The dictionary contains %d words total.\n", numWords);
        printf("The longest word %s has %d chars.\n", longestWord, maxWordLen);
        printf("The dictionary contains %d words of length %d.\n", numWordsAdded, wordSize);
        printf("Max size of the dynamic words array is %d.\n", capacity);
    }
    
    if (wordListMode) {
        printf("Words of length %d:\n", wordSize);

        if (numWordsAdded > 0) {
            for (int i = 0; i < numWordsAdded; i++) {
                printf("  %s\n", wordList[i]);
            }
        }

        else {
            printf("Dictionary has no words of length 25.\nTerminating program...\n");
            return 0;
        }
    }

    //-------------------------------------------------------------------
    // TODO - Task VII: play the game; repeatedly...
    //           - Input a character from user as their guess; 
    //             if guess is not a lower case letter OR has been 
    //             previously guessed, input another character.
    //           - Build a dynamic array of unique Pattern structs, 
    //             where each Pattern contains a heap-allocated C-string
    //             representing the current status of the final word, 
    //             with a '-' for each unsettled character; for each word
    //             in the current word list, produce an updated pattern  
    //             by replacing '-'s with current letter guess wherever 
    //             that letter appears in the word, and either appending 
    //             it as a new Pattern if it is unique in the array of 
    //             Patterns, OR incrementing the count subitem for the
    //             appropriate Pattern. The array of Patterns should 
    //             dynamically grow, beginning with maximum size 4, 
    //             doubling whenever more space is needed.
    //           - Find the most common pattern in the current word list 
    //             and update the final word pattern;
    //             i.e. find the Pattern in the array that has the 
    //             highest count subitem. Break ties as follows: 
    //                + for two Patterns with the same count, select the 
    //                  one with fewer occurences of the guessed letter;
    //                  i.e. smaller changes subitem
    //                + for two Patterns with the same count & changes,
    //                  select the one where the fist occurrence of the 
    //                  guessed letter is earlier in the word
    //           - Report to the user whether their guessed letter is in 
    //             the final word or not. End the game if the user has 
    //             used all of the allowed guesses or has solved the 
    //             final word. Otherwise, repeat the process by inputting 
    //             another letter from the user.
    //           - Throughout the game, produce print statements matching 
    //             the format of the sample outputs; only printing the 
    //             statistics [-s], word list [-w], letter list [-l], and 
    //             pattern list [-p] if the proper command-line flags are 
    //             turned ON;
    //-------------------------------------------------------------------
    
    char userInput;
    char* previouslyGuessed = (char*)malloc(sizeof(char) * numGuesses);
    bool inputGuessed = 0;
    int patternCapacity = 4, patternsAdded = 1;

    Pattern* patternArray = (Pattern*)malloc(sizeof(Pattern) * patternCapacity);

    char* finalPattern;
    char* updatePattern = (char*)malloc(sizeof(char) * wordSize);

    for (int i = 0; i < numGuesses; i++) { // initializes the previously guessed string
        previouslyGuessed[i] = 0;
    }

    // initializes the first pattern and the update pattern
    patternArray[0].pat = (char*)malloc(sizeof(char) * wordSize);
    for (int i = 0; i < wordSize; i++) {
        patternArray[0].pat[i] = '-';
        updatePattern[i] = '-';
    }

    finalPattern = patternArray[0].pat;

    while (1) {
        if (!inputGuessed) {
            printf("The word pattern is: %s\n\nNumber of guesses remaining: %d\n", finalPattern, numGuesses);
        }

        inputGuessed = 0;

        printf("Guess a letter (# to end game): ");

        scanf(" %c", &userInput);

        if (userInput == '#') {
            printf("Terminating game...\n");
            break;
        }

        for (int i = 0; i < strlen(previouslyGuessed); i++) {
            if (userInput == previouslyGuessed[i]) {
                inputGuessed = 1;
                break;
            }
        }

        if (inputGuessed) {
            printf("Letter previously guessed...\n");
            continue;
        }

        if (userInput < 'a' || userInput > 'z') {
            inputGuessed = 1;
            printf("Invalid letter...\n");
            continue;
        }

        previouslyGuessed[strlen(previouslyGuessed)] = userInput;
        numGuesses--;

        //TODO update patterns and final pattern
        //(for )

        if (numGuesses < 1) {
            printf("You ran out of guesses and did not solve the word.\n");
            break;
        }
    }
    //-------------------------------------------------------------------
    // TODO - Task VIII:free all heap-allocated memory to avoid potential 
    //                  memory leaks. Since the word size for each game 
    //                  play is a command-line argument, any array whose 
    //                  size depends on the word size should be 
    //                  dynamically heap-allocated, and thus must be 
    //                  tracked and freed
    //-------------------------------------------------------------------
    
    //FREE THE PATTERN ARRAY
    //for (int i = 0; i < patternsAdded; i++) {
    //    free(patternArray[i].pat);
    //}

    free(finalPattern);

    free(patternArray);
    free(updatePattern);

    free(previouslyGuessed);

    for (int i = 0; i < numWordsAdded; i++) {
        free(wordList[i]);
    }

    free(wordList);
    
    return 0;
}
