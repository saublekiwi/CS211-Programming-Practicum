/*
Martin Laugesen
10/22/2023
The program uses a file of state election data decided by user input (either through command line or durring runtime) to
calculate the minimum number of popular votes needed to win the presidency. There is a fast and quiet mode, regaurdless the
bulk of the work is done in a recursive function, calculating the states that are most optimal to win. Once the optimal
states are picked, the election information and picked state information is written to a file.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "MinPopVote.h"

bool setSettings(int argc, char** argv, int* year, bool* fastMode, bool* quietMode) {
    //------------------------------------------------   
    // TODO: Task 1 - write the setSettings() function
    //------------------------------------------------

    //sets the default values
    *fastMode = false;
    *quietMode = false;
    *year = 0;

    for (int arg = 1; arg < argc; arg++) {
        if (!strcmp(argv[arg], "-f")) { // fast mode check
            *fastMode = true;
        }

        else if (!strcmp(argv[arg], "-q")) { // quiet mode check
            *quietMode = true;
        }

        else if (!strcmp(argv[arg], "-y")) { // year check
            int yearUnconfirmed = atoi(argv[arg + 1]);

            if (yearUnconfirmed % 4 == 0 && yearUnconfirmed >= 1828 && yearUnconfirmed <= 2020) {
                *year = yearUnconfirmed;
            }
            arg++;
        }

        else {
            return false;
        }
    }

    return true;
}

void inFilename(char* filename, int year) {
    //------------------------------------------------   
    // TODO: Task 2 - write the inFilename() function
    //------------------------------------------------
    char yearString[5];

    sprintf(yearString, "%d", year);

    yearString[4] = '\0';

    strcpy(filename, "data/");
    strcat(filename, yearString);
    strcat(filename, ".csv");

    return;
}

void outFilename(char* filename, int year) {
    //------------------------------------------------   
    // TODO: Task 2 - write the outFilename() function
    //------------------------------------------------
    char yearString[5];

    sprintf(yearString, "%d", year);

    yearString[4] = '\0';

    strcpy(filename, "toWin/");
    strcat(filename, yearString);
    strcat(filename, "_win.csv");

    return;
}

bool parseLine(char* line, State* myState) {
    //------------------------------------------------   
    // TODO: Task 4 - write the parseLine() function
    //------------------------------------------------

    int numCommas = -1;
    char lineCopy[50];
    strcpy(lineCopy, line);
    char* comma;

    if (line[strlen(line) - 1] == '\n') { // removes \n if present
        line[strlen(line) - 1] = '\0';
    }

    char* token = strtok(lineCopy, ",");

    while (token != NULL) { // counts commas
        numCommas++;
        token = strtok(NULL, ",");
    }

    if (numCommas != 3) {
        return false;
    }

    //copies over the data using a pointer;
    comma = strchr(line, ',');
    *comma = '\0';
    strcpy(myState->name, line);
    line = comma + 1;

    comma = strchr(line, ',');
    *comma = '\0';
    strcpy(myState->postalCode, line);
    line = comma + 1;

    comma = strchr(line, ',');
    *comma = '\0';
    myState->electoralVotes = atoi(line);
    line = comma + 1;

    myState->popularVotes = atoi(line);

    return true;
}

bool readElectionData(char* filename, State* allStates, int* nStates) {
    //-----------------------------------------------------   
    // TODO: Task 5 - write the readElectionData() function
    //-----------------------------------------------------
    *nStates = 0;
    char line[100];

    FILE* electionDataFile = fopen(filename, "r");

    if (electionDataFile == NULL) {
        return false;
    }

    while (!feof(electionDataFile)) { // goes through each line of the file, sends it to parseline
        fgets(line, 100, electionDataFile);

        parseLine(line, &(allStates[*nStates]));
        (*nStates)++;
    }

    fclose(electionDataFile);

    allStates[*nStates - 1].name[0] = '\0'; 
    allStates[*nStates - 1].postalCode[0] = '\0';
    (*nStates)--;

    return true;
}

int totalEVs(State* states, int szStates) {
    //----------------------------------------------   
    // TODO: Task 6 - write the totalEVs() function;
    //                note test_totalEVs() is 
    //                provided in test.c to test
    //                the functionality of totalEVs()
    //                   >> make build_test
    //                   >> make run_test 
    //----------------------------------------------
    int total = 0;

    for (int state = 0; state < szStates; state++) {
        total += states[state].electoralVotes;
    }
    
    return total;
}

int totalPVs(State* states, int szStates) {
    //--------------------------------------------------   
    // TODO: Task 6 - write the totalPVs() function;
    //                then, write your own test function 
    //                test_totalPVs() in test.c
    //                   >> make build_test
    //                   >> make run_test 
    //--------------------------------------------------
    int total = 0;

    for (int state = 0; state < szStates; state++) {
        total += states[state].popularVotes;
    }
    
    return total;
}

MinInfo minPopVoteAtLeast(State* states, int szStates, int start, int EVs) { // USE 1828 FOR TESTING, LARGER DATASETS WILL CRASH SLOW MODE
    //----------------------------------------------
    // TODO: Task 7 - write minPopVoteAtLeast();
    //                a recursive helper function;
    //                returns MinInfo for the subset
    //                of [states] from index [start]
    //                to the end with the minimum
    //                popular vote total that has 
    //                sufficient [EVs] to win
    //----------------------------------------------
    if (EVs <= 0) { // EV base case
        MinInfo base2;
        base2.szSomeStates = 0;
        base2.subsetPVs = 0;
        base2.sufficientEVs = true;
        return base2;
    }

    if (start >= szStates) { // end of array base case
        MinInfo base;
        base.szSomeStates = 0;
        base.subsetPVs = 0;
        base.sufficientEVs = false;
        return base;
    }

    MinInfo includeState = minPopVoteAtLeast(states, szStates, start + 1, EVs - states[start].electoralVotes);

    // copy over current state information
    strcpy(includeState.someStates[includeState.szSomeStates].name, states[start].name);
    strcpy(includeState.someStates[includeState.szSomeStates].postalCode, states[start].postalCode);
    includeState.someStates[includeState.szSomeStates].electoralVotes = states[start].electoralVotes;
    includeState.someStates[includeState.szSomeStates].popularVotes = states[start].popularVotes;
    (includeState.szSomeStates)++;
    includeState.subsetPVs += states[start].popularVotes / 2 + 1;

    MinInfo excludeState = minPopVoteAtLeast(states, szStates, start + 1, EVs);

    if (includeState.sufficientEVs && excludeState.sufficientEVs) { // if both have sufficient EVs
        return (includeState.subsetPVs < excludeState.subsetPVs) ? includeState : excludeState; // returns the MinInfo with less PVs
    }

    else if (includeState.sufficientEVs) { // if include has sufficient EVs
        return includeState;
    }

    else { // if exclude has sufficient EVs or they are both insufficient
        return excludeState;
    }
}

MinInfo minPopVoteToWin(State* states, int szStates) {
    int totEVs = totalEVs(states,szStates);
    int reqEVs = totEVs/2 + 1; // required EVs to win election
    return minPopVoteAtLeast(states, szStates, 0, reqEVs);
}

MinInfo calcMemo (int start, int EVs, MinInfo** memo, MinInfo toCopy) { // copies a MinInfo into the memo array
    memo[start][EVs].subsetPVs = toCopy.subsetPVs;
    memo[start][EVs].sufficientEVs = toCopy.sufficientEVs;
    memo[start][EVs].szSomeStates = toCopy.szSomeStates;

    for (int state = 0; state < toCopy.szSomeStates; state++) {
        strcpy(memo[start][EVs].someStates[state].name, toCopy.someStates[state].name);
        strcpy(memo[start][EVs].someStates[state].postalCode, toCopy.someStates[state].postalCode);
        memo[start][EVs].someStates[state].electoralVotes = toCopy.someStates[state].electoralVotes;
        memo[start][EVs].someStates[state].popularVotes = toCopy.someStates[state].popularVotes;
    }
}

MinInfo minPopVoteAtLeastFast(State* states, int szStates, int start, int EVs, MinInfo** memo) {
    //----------------------------------------------   
    // TODO: Task 8 - write minPopVoteAtLeastFast();
    //                start by copying in fully
    //                functioning code from 
    //                minPopVoteAtLeast() and make
    //                additions for memoization
    //---------------------------------------------- 
    if (EVs <= 0) { // EV base case
        MinInfo base2;
        base2.szSomeStates = 0;
        base2.subsetPVs = 0;
        base2.sufficientEVs = true;
        return base2;
    }

    if (start >= szStates) { // end of array base case
        MinInfo base;
        base.szSomeStates = 0;
        base.subsetPVs = 0;
        base.sufficientEVs = false;
        return base;
    }

    if (memo[start][EVs].subsetPVs != -1) { // memo check
        return memo[start][EVs];
    }

    MinInfo includeState = minPopVoteAtLeastFast(states, szStates, start + 1, EVs - states[start].electoralVotes, memo);

    // copy over current state information
    strcpy(includeState.someStates[includeState.szSomeStates].name, states[start].name);
    strcpy(includeState.someStates[includeState.szSomeStates].postalCode, states[start].postalCode);
    includeState.someStates[includeState.szSomeStates].electoralVotes = states[start].electoralVotes;
    includeState.someStates[includeState.szSomeStates].popularVotes = states[start].popularVotes;
    (includeState.szSomeStates)++;
    includeState.subsetPVs += states[start].popularVotes / 2 + 1;

    MinInfo excludeState = minPopVoteAtLeastFast(states, szStates, start + 1, EVs, memo);

    if (includeState.sufficientEVs && excludeState.sufficientEVs) { // if both have sufficient EVs
        if (includeState.subsetPVs < excludeState.subsetPVs) { // include has lower subset PVs
            calcMemo(start, EVs, memo, includeState);
            return includeState;
        }

        else {
            calcMemo(start, EVs, memo, excludeState);
            return excludeState;
        }
    }

    else if (includeState.sufficientEVs) { // if include has sufficient EVs
        calcMemo(start, EVs, memo, includeState);
        return includeState;
    }

    else { // if exclude has sufficient EVs or they are both insufficient
        calcMemo(start, EVs, memo, excludeState);
        return excludeState;
    }
}

MinInfo minPopVoteToWinFast(State* states, int szStates) {
    int totEVs = totalEVs(states,szStates);
    int reqEVs = totEVs/2 + 1; // required EVs to win election

    MinInfo** memo = (MinInfo**)malloc((szStates+1)*sizeof(MinInfo*));
    for (int i = 0; i < szStates+1; ++i) {
        memo[i] = (MinInfo*)malloc((reqEVs+1)*sizeof(MinInfo));
        for (int j = 0; j < reqEVs+1; ++j) {
            memo[i][j].subsetPVs = -1;
        }
    }
    MinInfo res = minPopVoteAtLeastFast(states, szStates, 0, reqEVs, memo);
    
    //----------------------------------------------   
    // TODO: Task 8 - [memo] will go out of scope 
    //                upon return, so free all
    //                heap-allocated memory for 
    //                [memo] before return 
    //---------------------------------------------- 
    for (int i = 0; i < szStates + 1; i++) {
        free(memo[i]);
    }
    free(memo);

    return res;
}

bool writeSubsetData(char* filenameW, int totEVs, int totPVs, int wonEVs, MinInfo toWin) {
    //-----------------------------------------------------   
    // TODO: Task 9 - write the writeSubsetData() function
    //-----------------------------------------------------
    FILE* file = fopen(filenameW, "w");

    if (file == NULL) {
        return false;
    }

    fprintf(file, "%d,%d,%d,%d\n", totEVs, totPVs, wonEVs, toWin.subsetPVs); // writes the first line of the file

    for (int state = toWin.szSomeStates - 1; state >= 0; state--) { // writes the states/info to the file in reverse (alphabetical)
        fprintf(file, "%s,%s,%d,%d\n", toWin.someStates[state].name, toWin.someStates[state].postalCode, toWin.someStates[state].electoralVotes, toWin.someStates[state].popularVotes / 2 + 1);
    }

    fclose(file);

    return true;
}
