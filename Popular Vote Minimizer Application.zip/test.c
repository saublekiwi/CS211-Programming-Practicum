#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "MinPopVote.h"

bool test_totalEVs() {
    State aStates[10];
    int res;
    
    aStates[0].electoralVotes = 5;
    aStates[1].electoralVotes = 8;
    aStates[2].electoralVotes = 12;
    aStates[3].electoralVotes = 6;
    aStates[4].electoralVotes = 7;
    aStates[5].electoralVotes = 10;

    printf(" Checking totalEVs() for 5 States:\n");
    res = totalEVs(aStates,5);
    if (res != 38) {
        printf("  individual state EVs are 5, 8, 13, 6, 7\n");
        printf("  expected total EVs = 38, actual total EVs = %d\n",res);
        return 0;
    }

    aStates[0].electoralVotes = 5;
    aStates[1].electoralVotes = 8;
    aStates[2].electoralVotes = 12;
    aStates[3].electoralVotes = 6;
    aStates[4].electoralVotes = 7;
    aStates[5].electoralVotes = 15;
    aStates[6].electoralVotes = 12;
    aStates[7].electoralVotes = 8;
    aStates[8].electoralVotes = 14;
    aStates[9].electoralVotes = 13;
    
    printf(" Checking totalEVs() for 10 States:\n");
    res = totalEVs(aStates,10);
    if (res != 100) {
        printf("  expected total EVs = 100, actual total EVs = %d\n",res);
        return false;
    }

    return true;
}

bool test_totalPVs() {
    //--------------------------------------------------------   
    // TODO: Task 6 - write your own test case for totalPVs();
    //                use test_totalEVs() as a sample;
    //                make sure to test all components
    //--------------------------------------------------------
    State aStates[10];
    int res;
    
    aStates[0].popularVotes = 500;
    aStates[1].popularVotes = 800;
    aStates[2].popularVotes = 1200;
    aStates[3].popularVotes = 600;
    aStates[4].popularVotes = 700;
    aStates[5].popularVotes = 1000;

    printf(" Checking totalPVs() for 5 States:\n");
    res = totalPVs(aStates,5);
    if (res != 3800) {
        printf("  individual state PVs are 500, 800, 1300, 600, 700\n");
        printf("  expected total PVs = 3800, actual total PVs = %d\n",res);
        return 0;
    }

    aStates[0].popularVotes = 500;
    aStates[1].popularVotes = 800;
    aStates[2].popularVotes = 1200;
    aStates[3].popularVotes = 600;
    aStates[4].popularVotes = 700;
    aStates[5].popularVotes = 1500;
    aStates[6].popularVotes = 1200;
    aStates[7].popularVotes = 800;
    aStates[8].popularVotes = 1400;
    aStates[9].popularVotes = 1300;
    
    printf(" Checking totalPVs() for 10 States:\n");
    res = totalPVs(aStates,10);
    if (res != 10000) {
        printf("  expected total PVs = 10000, actual total PVs = %d\n",res);
        return false;
    }

    return true;
}

bool test_setSettings() {
    //-----------------------------------------------------------   
    // TODO: Task 6 - write your own test case for setSettings();
    //                use test_totalEVs() as a sample;
    //                make sure to test all components
    //-----------------------------------------------------------
    int year;
    bool fastMode, quietMode;

    int argc = 5;
    char* argv[5] = {"./app.exe", "-f", "-q", "-y", "2020"};

    printf("Testing argc = 5 and argv = {./app.exe -f -q -y 2020}, all valid:\n");
    bool set = setSettings(argc, argv, &year, &fastMode, &quietMode);

    if (!fastMode) {
        printf("Incorrectly set fastMode\n");
        return false;
    }
    else if (!quietMode) {
        printf("Incorrectly set quietMode\n");
        return false;
    }
    else if (year != 2020) {
        printf("Incorrectly set year\n");
        return false;
    }
    else if (!set) {
        printf("Function returned false when it should return true\n");
    }

    argc = 1;
    printf("Testing argc = 1 and argv = {./app.exe}, default values:\n");
    set = setSettings(argc, argv, &year, &fastMode, &quietMode);
    
    if (fastMode) {
        printf("Incorrectly set fastMode\n");
        return false;
    }
    else if (quietMode) {
        printf("Incorrectly set quietMode\n");
        return false;
    }
    else if (year != 0) {
        printf("Incorrectly set year\n");
        return false;
    }
    else if (!set) {
        printf("Function returned false when it should return true\n");
        return false;
    }

    argc = 5;
    argv[1] = "-v";
    printf("Testing argc = 5 and argv = {./app.exe -v -q -y 2020}, -v invalid:\n");
    set = setSettings(argc, argv, &year, &fastMode, &quietMode);

    if (set) {
        printf("Function returned true when it should return false\n");
        return false;
    }

    return true;
}

bool test_inFilename() {
    //----------------------------------------------------------   
    // TODO: Task 6 - write your own test case for inFilename();
    //                use test_totalEVs() as a sample;
    //                make sure to test all components
    //----------------------------------------------------------
    char result[20];
    
    printf("Testing 1828:\n");
    inFilename(result, 1828);
    if (strcmp(result, "data/1828.csv")) {
        return false;
    }

    printf("Testing 2020:\n");
    inFilename(result, 2020);
    if (strcmp(result, "data/2020.csv")) {
        return false;
    }

    return true;
}

bool test_outFilename() {
    //-----------------------------------------------------------   
    // TODO: Task 6 - write your own test case for outFilename();
    //                use test_totalEVs() as a sample;
    //                make sure to test all components
    //-----------------------------------------------------------
    char result[20];
    
    printf("Testing 1828:\n");
    outFilename(result, 1828);
    if (strcmp(result, "toWin/1828_win.csv")) {
        return false;
    }

    printf("Testing 2020:\n");
    outFilename(result, 2020);
    if (strcmp(result, "toWin/2020_win.csv")) {
        return false;
    }

    return true;
}

bool test_parseLine() {
    //---------------------------------------------------------   
    // TODO: Task 6 - write your own test case for parseLine();
    //                use test_totalEVs() as a sample;
    //                make sure to test all components
    //---------------------------------------------------------
    char testLine[50] = {"Delaware,DE,3,13944"};
    State testState;
    bool passed = true, worked;

    printf("Testing {Delaware,DE,3,13944}, all valid:\n");
    worked = parseLine(testLine, &testState);

    if (strcmp(testState.name, "Delaware")) {
        printf("Incorrectly set name\n");
        passed = false;
    }
    if (strcmp(testState.postalCode, "DE")) {
        printf("Incorrectly set postalCode\n");
        passed = false;
    }
    if (testState.electoralVotes != 3) {
        printf("Incorrectly set electoralVotes\n");
        passed = false;
    }
    if (testState.popularVotes != 13944) {
        printf("Incorrectly set popularVotes\n");
        passed = false;
    }
    if (!worked) {
        printf("Incorrectly returned false\n");
        passed = false;
    }

    printf("Testing {Delaware,DE,3}, missing PV:\n");
    strcpy(testLine, "Delaware,DE,3");
    worked = parseLine(testLine, &testState);

    if (worked) {
        printf("Incorrectly returned true\n");
        passed = false;
    }

    if (!passed) {
        return false;
    }

    return true;
}

bool test_readElectionData() {
    //----------------------------------------------------------------   
    // TODO: Task 6 - write your own test case for readElectionData();
    //                make sure to test all components
    //----------------------------------------------------------------
    State states[51];
    int nStates;
    char filename[20] = {"data/1828.csv"};
    bool passed = true;
    
    printf("Testing data/1828.csv:\n");
    readElectionData(filename, states, &nStates);

    if (nStates != 24) {
        printf("Incorrect number of states\n");
        return false;
    }

    if (strcmp(states[0].name, "Alabama")) {
        printf("Incorrectly set 1st state name, was %s should be Alabama\n", states[0].name);
        passed = false;
    }

    if (strcmp(states[4].postalCode, "IL")) {
        printf("Incorrectly set 5th state postalCode, was %s should be IL\n", states[4].postalCode);
        passed = false;
    }

    if (states[9].electoralVotes != 11) {
        printf("Incorrectly set 10th EV, was %d should be 11\n", states[9].electoralVotes);
        passed = false;
    }

    if (states[14].popularVotes != 45570) {
        printf("Incorrectly set 15th PV, was %d should be 45570\n", states[9].popularVotes);
        passed = false;
    }

    strcpy(filename, "data/2020.csv");
    printf("Testing data/2020.csv:\n");
    readElectionData(filename, states, &nStates);

    if (nStates != 51) {
        printf("Incorrect number of states\n");
        return false;
    }

    if (strcmp(states[0].name, "Alabama")) {
        printf("Incorrectly set 1st state name, was %s should be Alabama\n", states[0].name);
        passed = false;
    }

    if (strcmp(states[13].postalCode, "IL")) {
        printf("Incorrectly set 14th state postalCode, was %s should be IL\n", states[4].postalCode);
        passed = false;
    }

    if (states[20].electoralVotes != 10) {
        printf("Incorrectly set 21st EV, was %d should be 10\n", states[9].electoralVotes);
        passed = false;
    }

    if (states[50].popularVotes != 276765) {
        printf("Incorrectly set 51st PV, was %d should be 276765\n", states[9].popularVotes);
        passed = false;
    }

    if (!passed) {
        return false;
    }

    return true;
}

bool test_minPVsSlow() {
    //----------------------------------------------------------------- 
    // TODO: Task 7 - write your own test case for minPopVoteAtLeast();
    //                make sure to test all components
    //-----------------------------------------------------------------
    State states[4];
    int szStates = 4;
    int start = 0;
    int reqEVs = 10;

    strcpy(states[0].name, "A");
    strcpy(states[0].postalCode, "A");
    states[0].electoralVotes = 5;
    states[0].popularVotes = 60;

    strcpy(states[1].name, "B");
    strcpy(states[1].postalCode, "B");
    states[1].electoralVotes = 2;
    states[1].popularVotes = 20;

    strcpy(states[2].name, "C");
    strcpy(states[2].postalCode, "C");
    states[2].electoralVotes = 8;
    states[2].popularVotes = 80;

    strcpy(states[3].name, "D");
    strcpy(states[3].postalCode, "D");
    states[3].electoralVotes = 3;
    states[3].popularVotes = 20;

    printf("Testing:\nA\tEVs: 5\tPVs: 60\nB\tEVs: 2\tPVs: 20\nC\tEVs: 8\tPVs: 80\nD\tEVs: 3\tPVs: 20\n");
    MinInfo result = minPopVoteAtLeast(states, szStates, start, reqEVs);

    if (result.szSomeStates != 2 || result.subsetPVs != 52 || !(result.sufficientEVs) || strcmp(result.someStates[0].name, "D") || strcmp(result.someStates[1].name, "C")) {
        return false;
    }

    return true;
}

bool test_minPVsFast() {
    //--------------------------------------------------------------------- 
    // TODO: Task 8 - write your own test case for minPopVoteAtLeastFast();
    //                make sure to test all components
    //---------------------------------------------------------------------
    State states[15];
    int szStates = 15;

    strcpy(states[0].name, "A");
    strcpy(states[0].postalCode, "A");
    states[0].electoralVotes = 5;
    states[0].popularVotes = 60;

    strcpy(states[1].name, "B");
    strcpy(states[1].postalCode, "B");
    states[1].electoralVotes = 2;
    states[1].popularVotes = 20;

    strcpy(states[2].name, "C");
    strcpy(states[2].postalCode, "C");
    states[2].electoralVotes = 8;
    states[2].popularVotes = 80;

    strcpy(states[3].name, "D");
    strcpy(states[3].postalCode, "D");
    states[3].electoralVotes = 3;
    states[3].popularVotes = 20;


    strcpy(states[4].name, "AA");
    strcpy(states[4].postalCode, "A");
    states[4].electoralVotes = 5;
    states[4].popularVotes = 60;

    strcpy(states[5].name, "BB");
    strcpy(states[5].postalCode, "B");
    states[5].electoralVotes = 2;
    states[5].popularVotes = 20;

    strcpy(states[6].name, "CC");
    strcpy(states[6].postalCode, "C");
    states[6].electoralVotes = 8;
    states[6].popularVotes = 80;

    strcpy(states[6].name, "DD");
    strcpy(states[6].postalCode, "D");
    states[6].electoralVotes = 3;
    states[6].popularVotes = 20;


    strcpy(states[7].name, "AAA");
    strcpy(states[7].postalCode, "A");
    states[7].electoralVotes = 5;
    states[7].popularVotes = 60;

    strcpy(states[8].name, "BBB");
    strcpy(states[8].postalCode, "B");
    states[8].electoralVotes = 2;
    states[8].popularVotes = 20;

    strcpy(states[9].name, "CCC");
    strcpy(states[9].postalCode, "C");
    states[9].electoralVotes = 8;
    states[9].popularVotes = 80;

    strcpy(states[10].name, "DDD");
    strcpy(states[10].postalCode, "D");
    states[10].electoralVotes = 3;
    states[10].popularVotes = 20;


    strcpy(states[11].name, "AAAA");
    strcpy(states[11].postalCode, "A");
    states[11].electoralVotes = 5;
    states[11].popularVotes = 60;

    strcpy(states[12].name, "BBBB");
    strcpy(states[12].postalCode, "B");
    states[12].electoralVotes = 2;
    states[12].popularVotes = 20;

    strcpy(states[13].name, "CCCC");
    strcpy(states[13].postalCode, "C");
    states[13].electoralVotes = 8;
    states[13].popularVotes = 80;

    strcpy(states[14].name, "DDDD");
    strcpy(states[14].postalCode, "D");
    states[14].electoralVotes = 3;
    states[14].popularVotes = 20;

    printf("Testing:\nA\tEVs: 5\tPVs: 60\nB\tEVs: 2\tPVs: 20\nC\tEVs: 8\tPVs: 80\nD\tEVs: 3\tPVs: 20\n...\nAAAA\tEVs: 5\tPVs: 60\nBBBB\tEVs: 2\tPVs: 20\nCCCC\tEVs: 8\tPVs: 80\nDDDD\tEVs: 3\tPVs: 20\n");
    MinInfo result = minPopVoteToWinFast(states, szStates);

    if (result.szSomeStates != 6 || result.subsetPVs != 156 || !(result.sufficientEVs) || strcmp(result.someStates[0].name, "DDDD") || strcmp(result.someStates[1].name, "CCCC") || strcmp(result.someStates[2].name, "DDD") || strcmp(result.someStates[3].name, "CCC") || strcmp(result.someStates[4].name, "DD") || strcmp(result.someStates[5].name, "C")) {
        return false;
    }

    return true;
}

int main() {
    printf("Welcome to the Popular Vote Minimizer Testing Suite!\n\n");
    
    printf("Testing totalEVs()...\n"); 
    if (test_totalEVs()) {
        printf("  All tests PASSED!\n");
    } else {
        printf("  test FAILED.\n");
    }

    printf("Testing totalPVs()...\n"); 
    if (test_totalPVs()) {
        printf("  All tests PASSED!\n");
    } else {
        printf("  test FAILED.\n");
    }

    printf("Testing setSettings()...\n"); 
    if (test_setSettings()) {
        printf("  All tests PASSED!\n");
    } else {
        printf("  test FAILED.\n");
    }
    
    printf("Testing inFilename()...\n"); 
    if (test_inFilename()) {
        printf("  All tests PASSED!\n");
    } else {
        printf("  test FAILED.\n");
    }

    printf("Testing outFilename()...\n"); 
    if (test_outFilename()) {
        printf("  All tests PASSED!\n");
    } else {
        printf("  test FAILED.\n");
    }

    printf("Testing parseLine()...\n"); 
    if (test_parseLine()) {
        printf("  All tests PASSED!\n");
    } else {
        printf("  test FAILED.\n");
    }

    printf("Testing readElectionData()...\n"); 
    if (test_readElectionData()) {
        printf("  All tests PASSED!\n");
    } else {
        printf("  test FAILED.\n");
    }
    
    printf("Testing minPopVoteToWin()...\n"); 
    if (test_minPVsSlow()) {
        printf("  All tests PASSED!\n");
    } else {
        printf("  test FAILED.\n");
    }

    printf("Testing minPopVoteToWinFast()...\n"); 
    if (test_minPVsFast()) {
        printf("  All tests PASSED!\n");
    } else {
        printf("  test FAILED.\n");
    }

    return 0;
}
