#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

typedef struct Org_struct {
    char name[20];
    int* prey; //dynamic array of indices  
    int numPrey;
} Org;


void buildWeb(Org* web, int numOrgs, int predInd, int preyInd) {
    //TODO: build the web by adding the predator-prey relation to the food web.
    //      Inputs: 
    //          web - a dynamically allocated array of Orgs 
    //          numOrgs - number of organisms = size of web[]
    //          predInd - predator index in web[]; an entry to its prey[] subitem will be added
    //          preyInd - prey index in web[]; will be added to predator's prey[] subitem
    //      Outputs:
    //          web - array is updated and implicitly returned (previously allocated on heap)
    //        
    //      For the predator-prey relation...
    //      (1) if the predator's prey[] array is empty, allocate memory for one index
    //          otherwise, reallocate predator's prey[] array to allow one more index
    //      (2) append the prey index as the last element of the predator's prey[] array 
    //      (3) update the numPrey subitem for the predator appropriately 

    // allocates space for the first prey element if there isn't one already
    if (web[predInd].numPrey == 0) {
        web[predInd].prey = (int*)malloc(sizeof(int));
    }

    else {
        int* newPrey = (int*)malloc(sizeof(int) * (web[predInd].numPrey + 1)); // allocates space for a prey array one prey larger than it is currently

        for (int i = 0; i < web[predInd].numPrey; i++) { // copies the old array to the new array
            newPrey[i] = web[predInd].prey[i];
        }

        free(web[predInd].prey); // frees the old array

        web[predInd].prey = newPrey; // sets the prey array pointer to the new prey array
    }

    web[predInd].prey[web[predInd].numPrey] = preyInd; // adds the new prey to end of array

    web[predInd].numPrey++; // updates numPrey

    return;
}


void extinction(Org** web, int* numOrgs, int index) {
    //TODO: remove the organism associated with [index] from web.
    //      Inputs: 
    //          web - a dynamically allocated array of Orgs 
    //          numOrgs - number of organisms = size of web[]
    //          index - organism index in web[] to remove
    //      Outputs:
    //          web - pointer passed-by-pointer; memory address of web array changes due to reallocation
    //          numOrgs - passed-by-pointer; must be decremented since web[] loses an organism
    //
    //      Remember to do the following:
    //      1. remove organism at index from web[] - DO NOT use realloc(), instead...
    //          (a) free any malloc'd memory associated with organism at index; i.e. its prey[] subitem
    //          (b) malloc new space for the array with the new number of Orgs
    //          (c) copy all but one of the old array elements to the new array, 
    //              some require shifting forward to overwrite the organism at index
    //          (d) free the old array
    //          (e) update the array pointer to the new array
    //          (f) update numOrgs
    //      2. remove index from all organsisms' prey[] array subitems - DO NOT use realloc(), instead...
    //          (a) search for index in all organisms' prey[] arrays; when index is found:
    //                [i] malloc new space for the array with the new number of ints
    //               [ii] copy all but one of the old array elements to the new array, 
    //                    keeping the same order some require shifting forward
    //              [iii] free the old array
    //               [iv] update the array pointer to the new array
    //                [v] update the numPrey subitem accordingly
    //          (b) update all organisms' prey[] elements that are greater than index, 
    //              which have been shifted forward in the web array
    //
    //          Edge case: check the size array being malloc'ed; 
    //                     for a web with only one organism and 
    //                     that orgranism goes extinct, 
    //                     instead of malloc'ing an empty array, 
    //                     explicitly set the pointer to NULL;
    //                     see the web[] allocation in main() as an example

    if (*numOrgs < 2) { // checks for complete extinction, completely frees the web, points it to NULL, and exits the function
        free((*web)[index].prey);
        free(*web);
        (*web) = NULL;
        (*numOrgs)--;
        return;
    }

    free((*web)[index].prey); // frees the prey array of the excinct organism

    Org* newWeb = (Org*)malloc(sizeof(Org) * (*numOrgs - 1)); // allocates space for the web without the extinct organism

    for (int i = 0; i < index; i++) { // copies over the organims stopping before index
        newWeb[i] = (*web)[i];
    }

    for (int i = index + 1; i < *numOrgs; i++) { // copies over the organisms after index
        newWeb[i - 1] = (*web)[i];
    }

    free(*web); // frees old web

    (*web) = newWeb; // points web to newWeb
    (*numOrgs)--; // updates numOrgs

    for (int i = 0; i < *numOrgs; i++) { // copies over the prey arrays, of the organisms, ignoring the extinct index
        for (int j  = 0; j < (*web)[i].numPrey; j++) {
            if ((*web)[i].prey[j] == index) { // checks if current prey is extinct
                int* updatedPrey = NULL;
                if ((*web)[i].numPrey - 1 > 0) { // if this organism has prey
                    updatedPrey = (int*)malloc(sizeof(int) * ((*web)[i].numPrey - 1)); // allocates space for new prey array

                    for (int k = 0; k < j; k++) { // copies over prey, stopping at the current (extinct) one
                        updatedPrey[k] = (*web)[i].prey[k];
                    }

                    for (int k = j + 1; k < (*web)[i].numPrey; k++) { // copies over prey after the current (extinct) one
                        updatedPrey[k - 1] = (*web)[i].prey[k];
                    }
                }
                free((*web)[i].prey); // frees old prey
                (*web)[i].prey = updatedPrey; // sets organism's prey to the updated version
                (*web)[i].numPrey--; // updates numPrey
            }
        }
    }

    for (int i = 0; i < *numOrgs; i++) { // updates the prey above index, to account for the shifting up after thhe web was updated
        for (int j  = 0; j < (*web)[i].numPrey; j++) {
            if ((*web)[i].prey[j] > index) {
                (*web)[i].prey[j]--;
            }
        }
    }
}


void printWeb (Org* web, int numOrgs) { // prints the organism web, including what they eat
    for (int i = 0; i < numOrgs; i++) { // loops through the organisms
        printf("  %s", web[i].name);

        if (web[i].numPrey > 0) {
            printf(" eats ");

            for (int j = 0; j < web[i].numPrey; j++) { // loops through organism's prey
                if (j == 0) {
                    printf("%s", web[web[i].prey[j]].name);
                }

                else {
                    printf(", %s", web[web[i].prey[j]].name);
                }
            }
        }

        printf("\n");
    }
}


void printApex(Org* web, int numOrgs) { // prints apex predators
    for (int i = 0; i < numOrgs; i++) { // loops through organisms
        bool apex = true;

        for (int j = 0; j < numOrgs; j++) { // checks if current organism appears on any prey list, if it does apex is false
            for (int k = 0; k < web[j].numPrey; k++) {
                if (web[j].prey[k] == i) {
                    apex = false;
                }
            }
        }

        if (apex) {
            printf("  %s\n", web[i].name);
        }
    }
}


void printProducer(Org* web, int numOrgs) { // prints producers
    for (int i = 0; i < numOrgs; i++) { // loops through organisms
        if (web[i].numPrey == 0) {
            printf("  %s\n", web[i].name);
        }
    }
}


void printFlexible(Org* web, int numOrgs) { // prints flexible eaters
    int max = 0;

    for (int i = 0; i < numOrgs; i++) { // finds the max number of prey
        if (web[i].numPrey > max) {
            max = web[i].numPrey;
        }
    }

    for (int i = 0; i < numOrgs; i++) { // if an organim has the max number of prey it is printed
        if (web[i].numPrey == max) {
            printf("  %s\n", web[i].name);
        }
    }
}


void printTasty(Org* web, int numOrgs) { // prints the tastiest organisms
    int max = 0, numEaten;

    for (int i = 0; i < numOrgs; i++) { // loops through organisms, finding the qualification to be the tastiest
        numEaten = 0;

        for (int j = 0; j < numOrgs; j++) { // checks how many times the organism is on another organism's prey list
            for (int k = 0; k < web[j].numPrey; k++) {
                if (web[j].prey[k] == i) {
                    numEaten++;
                }
            }
        }

        if (numEaten > max) { // updates the max times eaten
            max = numEaten;
        }
    }

    for (int i = 0; i < numOrgs; i++) { // loops through organisms
        numEaten = 0;

        for (int j = 0; j < numOrgs; j++) { // finds the number of times the current organism is eaten
            for (int k = 0; k < web[j].numPrey; k++) {
                if (web[j].prey[k] == i) {
                    numEaten++;
                }
            }
        }

        if (numEaten == max) { //prints them if the number of times they're eaten is equal to the max
            printf("  %s\n", web[i].name);
        }
    }
}


void printHeight(Org* web, int numOrgs) { // prints organism heights
    int height[numOrgs]; // an array to store the organism heights
    bool changed = true;

    for (int i = 0; i < numOrgs; i++) { // initializes the height array
        height[i] = 0;
    }

    while (changed) { // while height[] was changed on the last loop
        changed = false;
        for (int i = 0; i < numOrgs; i++) { // loops through organisms
            for (int j = 0; j < web[i].numPrey; j++) { // loops through current organism's prey
                if (height[web[i].prey[j]] >= height[i]) { // if the organism has prey the same or heigher height, the organism height it increased by 1
                    height[i] = height[web[i].prey[j]] + 1;
                    changed = true;
                }
            }
        }
    }

    for (int i = 0; i < numOrgs; i++) { // prints organism heights
        printf("  %s: %d\n", web[i].name, height[i]);
    }
}


void printVore(Org* web, int numOrgs) { // prints organism vore type
    int voreType[numOrgs]; // an array to store vore types
    bool plantPrey, animalPrey;

    for (int i = 0; i < numOrgs; i++) { // initializes voreType[]
        voreType[i] = -1;
    }

    for (int i = 0; i < numOrgs; i++) { // sets the producers (0), everything else is set to herbivore (1)
        if (web[i].numPrey == 0) {
            voreType[i] = 0;
        }

        else {
            voreType[i] = 1;
        }
    }

    for (int i = 0; i < numOrgs; i++) { // loops through organisms
        plantPrey = false;
        animalPrey = false;

        if (web[i].numPrey > 0) { // skipping producers
            for (int j = 0; j < web[i].numPrey; j++) { // loops through the prey list and tracks which type of prey current organism has
                if (voreType[web[i].prey[j]] == 0) {
                    plantPrey = true;
                }

                else {
                    animalPrey = true;
                }
            }

            if (plantPrey && animalPrey) { // plant and animal prey = omnivore (2)
                voreType[i] = 2;
            }

            else if (!plantPrey && animalPrey) { // only animal prey = carnivore (3)
                voreType[i] = 3;
            }
        }
    }

    printf("  Producers:\n"); 
    for (int i = 0; i < numOrgs; i++) { // prints producers
        if (voreType[i] == 0) {
            printf("    %s\n", web[i].name);
        }
    }

    printf("  Herbivores:\n");
    for (int i = 0; i < numOrgs; i++) { // prints herbivores
        if (voreType[i] == 1) {
            printf("    %s\n", web[i].name);
        }
    }

    printf("  Omnivores:\n");
    for (int i = 0; i < numOrgs; i++) { // prints omnivores
        if (voreType[i] == 2) {
            printf("    %s\n", web[i].name);
        }
    }

    printf("  Carnivores:\n");
    for (int i = 0; i < numOrgs; i++) { // prints carnivores
        if (voreType[i] == 3) {
            printf("    %s\n", web[i].name);
        }
    }
}



int main(void) {

    int numOrgs;
    printf("Welcome to the Food Web Application\n");
    printf("--------------------------------\n");
    printf("Enter number of organisms:\n");
    scanf("%d",&numOrgs);

    Org* web = NULL;
    if(numOrgs > 0) { //Do not malloc an empty array, leave it pointing to NULL
        web = (Org*)malloc(numOrgs*sizeof(Org));
    }
    
    printf("Enter names for %d organisms:\n", numOrgs);
    for (int i = 0; i < numOrgs; ++i) {
        scanf("%s",web[i].name);
        web[i].prey = NULL;
        web[i].numPrey = 0;
    }

    printf("Enter number of predator/prey relations:\n");
    int numRels;
    scanf("%d",&numRels);

    printf("Enter the pair of indices for the %d predator/prey relations\n",numRels);
    printf("the format is [predator index] [prey index]:\n");
    
    int predInd, preyInd;
    for (int i = 0; i < numRels; ++i) {
        scanf("%d %d",&predInd, &preyInd);
        buildWeb(web,numOrgs,predInd,preyInd);
    }
    printf("--------------------------------\n\n");

    printf("Food Web Predators & Prey:\n");
    //TODO: print the Food Web Organisms with what they eat (i.e. prey)
    printWeb(web, numOrgs);
    printf("\n");

    printf("Apex Predators:\n");
    //TODO: identify and print the organisms not eaten by any others
    printApex(web, numOrgs);
    printf("\n");

    printf("Producers:\n");
    //TODO: identify and print the organisms that eat no other organisms
    printProducer(web, numOrgs);
    printf("\n");

    printf("Most Flexible Eaters:\n");
    //TODO: identity and print the organism(s) with the most prey
    printFlexible(web, numOrgs);
    printf("\n");

    printf("Tastiest Food:\n");
    //TODO: identity and print organism(s) eaten by the most other organisms
    printTasty(web, numOrgs);
    printf("\n");

    printf("Food Web Heights:\n");
    //TODO: calculate and print the length of the longest chain from a 
    //      producer to each organism
    printHeight(web, numOrgs);
    printf("\n");

    printf("Vore Types:\n");
    //TODO: classify all organisms and print each group
    //      (producers, herbivores, omnivores, & carnivores)
    printVore(web, numOrgs);
    printf("\n");

    printf("--------------------------------\n");
    int extInd;
    printf("Enter extinct species index:\n");
    scanf("%d",&extInd);
    printf("Species Extinction: %s\n", web[extInd].name);
    extinction(&web,&numOrgs,extInd);
    printf("--------------------------------\n\n");


    printf("UPDATED Food Web Predators & Prey:\n");
    //TODO: print the UPDATED Food Web Organisms with what they eat (i.e. prey), AFTER THE EXTINCTION
    printWeb(web, numOrgs);
    printf("\n");

    printf("UPDATED Apex Predators:\n");
    //TODO: AFTER THE EXTINCTION, identify and print the organisms not eaten by any other
    printApex(web, numOrgs);
    printf("\n");

    printf("UPDATED Producers:\n");
    //TODO: AFTER THE EXTINCTION, identify and print the organisms that eat no other organisms
    printProducer(web, numOrgs);
    printf("\n");

    printf("UPDATED Most Flexible Eaters:\n");
    //TODO: AFTER THE EXTINCTION, identity and print the organism(s) with the most prey
    printFlexible(web, numOrgs);
    printf("\n");

    printf("UPDATED Tastiest Food:\n");
    //TODO: AFTER THE EXTINCTION, identity and print organism(s) eaten by the most other organisms
    printTasty(web, numOrgs);
    printf("\n");

    printf("UPDATED Food Web Heights:\n");
    //TODO: AFTER THE EXTINCTION, calculate and print the length of the longest chain from a 
    //      producer to each organism
    printHeight(web, numOrgs);
    printf("\n");

    printf("UPDATED Vore Types:\n");
    //TODO: AFTER THE EXTINCTION, classify all organisms and print each group
    //      (producers, herbivores, omnivores, & carnivores)
    printVore(web, numOrgs);
    printf("\n");
    printf("--------------------------------\n");

    //TODO: make sure to free all malloc'd memory to prevent potential leaks
    for (int i = 0; i < numOrgs; i++) { // frees all the prey arrays
        free(web[i].prey);
    }
    free(web); // frees the organism web

    return 0;
}
