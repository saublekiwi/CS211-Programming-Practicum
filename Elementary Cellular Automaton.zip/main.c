
/*-------------------------------------------
Program 1: Elementary Cellular Automaton
Course: CS 211, Fall 2023, UIC
System: Advanced zyLab
Author: Martin Laugesen
-------------------------------------------*/

#include <stdio.h>
#include <stdbool.h> 

const int WORLD_SIZE = 65;

typedef struct cell_struct{
    bool state[3]; //active status for [left, me, right] cells 
    bool active; //current active status for this cell
} cell;

//convert an 8-bit integer rule (0-255) to array of bits 
//(stored in reverse order)
//   ex: rule = 6  = 00000110 -> [01100000] 
//   ex: rule = 30 = 00011110 -> [01111000] 
//   ex: rule = 65 = 01000001 -> [10000010]
//return true if input rule is valid (0-255)
//return false if input rule is invalid
bool setBitArray(bool bitArray[8], int rule) {

        //TODO: Task 1 - write the setBitArray() function

        if (0 <= rule && rule <= 255) {
            int bit = 0;

            while (bit < 8) {
                if (rule % 2 == 0) {
                    bitArray[bit] = 0;
                    rule /= 2;
                }
                
                else {
                    bitArray[bit] = 1;
                    rule /= 2;
                }
                bit++;
            }
            return true;
            
        }

        return false;
}

//convert a 3-bit state array to its 
//associated index of the rule# bit array
//   ex: {0 0 0} -> 0
//   ex: {0 0 1} -> 1
//   ex: {1 0 1} -> 5
int stateToIndex(bool state[3]) {

    //TODO: Task 4 - write the stateToIndex() function
    int idx = 0;

    if (state[0]) {
        idx += 4;
    }

    if (state[1]) {
        idx += 2;
    }

    if (state[2]) {
        idx += 1;
    }

    return idx;
}

//update the state array for each cell in the world array based on the
//current status of active for the nearby [left,me,right] cells
//note: world is assumed periodic/cyclic,
//with front-to-back and back-to-front wrapping 
void setStates(cell world[WORLD_SIZE]) {

    //TODO: Task 5 - write the setStates() function

    for (int i = 0; i < WORLD_SIZE; i++) {
        world[i].state[1] = world[i].active;

        if (i == 0) {
            world[i].state[0] = world[WORLD_SIZE - 1].active;
            world[i].state[2] = world[i + 1].active;
        }

        else if (i == (WORLD_SIZE - 1)) {
            world[i].state[0] = world[i - 1].active;
            world[i].state[2] = world[0].active;
        }

        else {
            world[i].state[0] = world[i - 1].active;
            world[i].state[2] = world[i + 1].active;
        }
    }

    return;
}

//evolve each cell's active status to the next generation 
//  using its state array
//ruleBitArray contains the 8-bits for the rule#, 
//  stored in reverse order
void evolveWorld(cell world[WORLD_SIZE], bool ruleBitArray[8]) {
    int idx;

    //TODO: Task 7 - write the evolveWorld() function
    for (int i = 0; i < 65; i++) {
        idx = stateToIndex(world[i].state);
        world[i].active = ruleBitArray[idx];
    }

    return;
}

// prints the current evolution line, takes in the world array and "reads" it
void print_line(cell world[WORLD_SIZE]) {
    for (int i = 0; i < 65; i++) {
        if (world[i].active) {
            printf("*");
        }

        else {
            printf(" ");
        }
    }
    printf("\n");

    return;
}


int main() {
    cell world[WORLD_SIZE];

    printf("Welcome to the Elementary Cellular Automaton!\n");

    //TODO: Task 2 - read in a valid rule# and
    //      generate the rule's 8-bit rule bit array 
    //      print the bit array in correct binary number order

    bool bit_array_worked = false;
    bool bitArray[8];
    int rule;

    // requests the rule until a valid rule is entered, creates bit array and displays it (reverse from how it's stored)
    while (!bit_array_worked) {

        printf("Enter the rule # (0-255):\n");
        scanf("%d", &rule);
        bit_array_worked = setBitArray(bitArray, rule);

        if (bit_array_worked) {
            printf("The bit array for rule #%d is %d%d%d%d%d%d%d%d\n", rule, bitArray[7], bitArray[6], bitArray[5], bitArray[4], bitArray[3], bitArray[2], bitArray[1], bitArray[0]);
        }
    }

    //TODO: Task 3 - use the rule bit array to report the evolution 
    //      step for all possible cell states.
    //      follow the format of the sample output exactly

    printf("\nThe evolution of all possible states are as follows:\n");

    char evolution_array[122];

    // format of line 1
    for (int i = 0; i < 61;) {
        evolution_array[i] = '|';
        i++;

        for (int k = 0; k < 3; k++) {
            evolution_array[i] = ' ';
            i++;
        }
    }

    evolution_array[61] = '\n'; // moves to the second line of displaying the possible states

    // format of line 2
    for (int i = 62; i < 122;) {
        evolution_array[i] = ' ';
        i++;
        evolution_array[i] = '|';
        i++;
        evolution_array[i] = ' ';
        i++;
        evolution_array[i] = '|';
        i++;
        evolution_array[i] = ' ';
        i++;
        for (int k = 0; k < 3; k++) {
            evolution_array[i] = ' ';
            i++;
        }
    }

    // the top line of states is constant
    evolution_array[1] = '*';
    evolution_array[2] = '*';
    evolution_array[3] = '*';
    evolution_array[9] = '*';
    evolution_array[10] = '*';
    evolution_array[17] = '*';
    evolution_array[19] = '*';
    evolution_array[25] = '*';
    evolution_array[34] = '*';
    evolution_array[35] = '*';
    evolution_array[42] = '*';
    evolution_array[51] = '*';

    // updates the evolution array based on the array
    for (int i = 7; i >= 0; i--) {
        if (bitArray[i] == 1) {
            evolution_array[120 - 8 * i] = '*';
        }
    }

    // prints the evolution array (string)
    for (int i = 0; i < 122; i++) {
        printf("%c", evolution_array[i]);
    }

    //TODO: Task 6 - read in the total number of generation evolution 
    //      steps from the user and initialize the world with ONLY the 
    //      middle cell active, all other cells should be inactive; 
    //      make sure to set the state array for each cell.

    printf("\nEnter the number of generations: ");

    int num_generations;

    scanf("%d", &num_generations);

    // sets all states and active to false
    for (int i = 0; i < 65; i++) {
        for (int j = 0; j < 3; j++) {
            world[i].state[j] = false;
        }
        world[i].active = false;
    }

    world[32].active = true; // sets the center active to true

    setStates(world); // sets the states with the newly updated active

    printf("\nInitializing world & evolving...\n");

    print_line(world);

    //TODO: Task 8 - evolve the world the user-specified number  
    //      of generations, printing each active cell as '*' and
    //      each non-active cell as ' ' (whitespace) after each
    //      evolution step to the next generation
    for (int line = 1; line < num_generations; line++) {

        evolveWorld(world, bitArray);

        setStates(world);

        print_line(world);
    }

    return 0;
}
